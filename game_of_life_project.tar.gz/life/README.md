# Game of Life — hybrid MPI + OpenMP

Final project, *Parallelization of Algorithms*.
Conway's Game of Life on a torus, with a sequential baseline and a hybrid
MPI + OpenMP version, correctness tests and a scaling benchmark.

## Files

| File | What it is |
|---|---|
| `src/common.h` | Config parsing, deterministic initial state, checksum, the Life rule (shared by both programs) |
| `src/gol_seq.c` | Sequential reference (no MPI, no OpenMP) |
| `src/gol_hybrid.c` | Hybrid version: 1D row decomposition, halo exchange, OpenMP inside each strip |
| `tests/test_correctness.py` | Known-pattern tests + sequential-vs-hybrid comparison (156 checks) |
| `bench/run_bench.py` | Strong and weak scaling measurements -> `results/*.csv` |
| `bench/plot.py` | Speedup, efficiency, mode comparison, weak scaling graphs |

## Build and run

Requirements: `gcc`, an MPI implementation (OpenMPI or MPICH) with `mpicc`/`mpirun`, Python 3 with `matplotlib`.

```bash
make                    # builds gol_seq and gol_hybrid
make test               # correctness tests (must print "0 failed")

./gol_seq -r 2048 -c 2048 -s 100
mpirun -np 4 ./gol_hybrid -r 2048 -c 2048 -s 100 -t 2 -m overlap

python3 bench/run_bench.py --cores 8   # use your PHYSICAL core count
python3 bench/plot.py                  # graphs appear in results/
```

Options (both programs): `-r rows -c cols -s steps -d density -S seed -p pattern -o outfile`,
hybrid only: `-t omp_threads -m sync|overlap`. Patterns: `random`, `glider`, `blinker`, `block`.
`-o file` writes the final grid as text (use only for small grids).
Every run prints one `RESULT ...` line with the time, a global checksum and the population.

On a machine with fewer cores than processes use `MPIRUN_ARGS="--oversubscribe"`.

## Design

**Problem.** Each cell is alive/dead; every generation a live cell with 2 or 3 live
neighbours survives, a dead cell with exactly 3 is born. Edges wrap (torus).
Work per step is O(R·C), communication is O(C) per process → computation dominates
for large grids, so the problem scales well.

**Data ownership.** The R×C grid is split into horizontal strips. Rank r owns
its rows and is the only one that writes them. Each rank stores two extra *halo* rows
(copies of the neighbours' border rows). Initial state is computed from global
coordinates (`init_cell(i,j)`), so each rank builds its own strip without any scatter,
and the result does not depend on the number of processes.

**Communication.** Per generation each rank sends its first row up and its last row
down (and receives the two halos). One halo row suffices because the stencil reaches 1 row.
- `sync`: two `MPI_Sendrecv` calls (deadlock-free by construction).
- `overlap`: `MPI_Irecv`/`MPI_Isend`, compute the inner rows (they need no halo) while
  messages are in flight, `MPI_Waitall`, then compute the 2 border rows.

**Shared memory.** Inside a rank, `#pragma omp parallel for schedule(static)` over rows.
Threads write different rows of the output buffer, so there are no races. MPI is used
with `MPI_THREAD_FUNNELED` (only the main thread calls MPI, outside parallel regions).

**Correctness.** (1) Known patterns: block (still life), blinker (period 2), glider
(moves (+1,+1) per 4 generations, returns after 4N steps on an N×N torus). (2) Random grids:
final grid of the hybrid program must be identical to the sequential one for many
(P, threads, mode, size) combinations, including row counts not divisible by P.
(3) The benchmark asserts that checksums match the sequential run on every measurement.

**Metrics.** speedup = T_seq / T(c) with T_seq from the separate sequential program;
efficiency = speedup / c; weak scaling keeps rows-per-core fixed and looks at time.

## Questions to be ready for at the defense

1. **Why do we need halo rows, and why exactly one?** A cell reads its 8 neighbours,
   at most 1 row away. Rows at the strip border need data from the other rank.
2. **What happens if every rank does `MPI_Send` then `MPI_Recv`?** For large messages
   `MPI_Send` may block until the receive is posted → everybody waits → deadlock.
   `MPI_Sendrecv` (or non-blocking calls) avoids it.
3. **Why are two tags used (`TAG_UP`, `TAG_DOWN`)?** With P=2 both neighbours are the same
   rank; tags keep the "up" message and the "down" message from being mixed up.
4. **Why does overlap sometimes not help?** Many MPI implementations only progress messages
   inside MPI calls; messages are small (one row) compared with the compute; there may be no
   spare core for communication. Measure it and explain what you see.
5. **Why does speedup stop growing?** Fixed problem size: compute per core shrinks, halo
   cost stays constant (Amdahl-like); memory bandwidth saturates (the stencil does little
   arithmetic per byte); hyper-threads are not real cores.
6. **Strong vs weak scaling?** Strong: fixed total size, ask "how much faster". Weak: fixed
   size per core, ask "does time stay flat".
7. **Why is the checksum a sum of per-cell hashes?** Addition is commutative, so the order of
   summation (threads, ranks) does not matter, but the hash depends on position, so a
   wrongly moved cell changes the value.
8. **Why does the sequential baseline not use MPI/OpenMP?** Honest speedup: comparing against
   the hybrid program on 1 core would hide its own overhead.
9. **Why `schedule(static)`?** Every row costs the same, so static has no scheduling overhead
   and gives contiguous blocks (good cache use).
10. **Possible improvements.** 2D decomposition (less communicated data per process when P is
    large: perimeter ~ 1/√P instead of constant row length), bit-packing cells (8× less memory
    traffic), temporal blocking (several generations per halo exchange with wider halos).

## Before you present

- Run `make test`, then the benchmark **on your machine** and use your own graphs.
- Be ready to change something live (e.g. swap `Sendrecv` for blocking Send/Recv and explain).
- Cite any external source you use (the guide requires it).
